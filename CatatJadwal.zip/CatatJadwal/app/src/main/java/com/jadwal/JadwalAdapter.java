package com.jadwal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class JadwalAdapter extends ArrayAdapter<Jadwal> {

    private int resourceLayout;
    private Context mContext;

    public JadwalAdapter(Context context) {
        super(context, R.layout.row_jadwal, new ArrayList<>());
        this.resourceLayout = R.layout.row_jadwal;
        this.mContext = context;
    }
    public void tambahJadwal(Jadwal jadwal){
        add(jadwal);
        notifyDataSetChanged();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            LayoutInflater vi;
            vi = LayoutInflater.from(mContext);
            v = vi.inflate(resourceLayout, null);
        }
        Jadwal p = getItem(position);
        if (p != null) {
            TextView tvTanggal = (TextView) v.findViewById(R.id.tv_tanggal);
            TextView tvKegiatan = (TextView) v.findViewById(R.id.tv_kegiatan);
            tvTanggal.setText(new SimpleDateFormat("dd MMMM yyyy").format(p.tanggal));
            tvKegiatan.setText(p.kegiatan);
        }
        return v;
    }

}