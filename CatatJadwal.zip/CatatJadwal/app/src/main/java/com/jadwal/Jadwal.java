package com.jadwal;

import java.util.Date;

public class Jadwal {
    Date tanggal;
    String kegiatan;

    public Jadwal(Date tanggal, String kegiatan) {
        this.tanggal = tanggal;
        this.kegiatan = kegiatan;
    }
}
