package com.jadwal;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MainActivity extends AppCompatActivity {
    Calendar calendar = Calendar.getInstance();
    EditText tanggal, kegiatan;
    Button simpan;
    ListView jadwal;
    Date dataTanggal;
    JadwalAdapter jadwalAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tanggal = findViewById(R.id.et_tanggal);
        kegiatan = findViewById(R.id.et_kegiatan);
        simpan = findViewById(R.id.btn_simpan);
        jadwal = findViewById(R.id.lv_jadwal);
        jadwalAdapter = new JadwalAdapter(this);
        jadwal.setAdapter(jadwalAdapter);

        DialogInterface.OnClickListener dialogClickListener = (dialog, which) -> {
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    jadwalAdapter.add(new Jadwal(dataTanggal, kegiatan.getText().toString()));
                    Toast.makeText(this,"Jadwal berhasil ditambahkan",Toast.LENGTH_SHORT).show();
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    break;
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Yakin ingin menambahkan jadwal?").setPositiveButton("Ya", dialogClickListener)
                .setNegativeButton("Tidak", dialogClickListener);

        tanggal.setOnClickListener(view -> showCalendar());
        simpan.setOnClickListener(view -> {
            if(isValid()){
                builder.show();
            }
        });
    }
    private boolean isValid(){
        boolean valid = true;
        if(kegiatan.getText().toString().isEmpty()){
            kegiatan.setError("Tidak Boleh Kosong");
            valid = false;
        }
        if(tanggal.getText().toString().isEmpty()){
            tanggal.setError("Tidak Boleh Kosong");
            valid = false;
        }
        return valid;
    }
    private void showCalendar(){
        tanggal.setShowSoftInputOnFocus(false);
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view1, year, month, dayOfMonth) -> {
                    dataTanggal =new GregorianCalendar(year,month,dayOfMonth).getTime();
                    tanggal.setText(new SimpleDateFormat("dd MMMM yyyy").format(dataTanggal));
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        if(!datePickerDialog.isShowing()) {
            datePickerDialog.show();
        }
    }
}